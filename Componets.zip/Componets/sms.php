<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Send SMS</title>
</head>
<body>
    <h2>Send SMS</h2>
    <form method="POST" action="">
        <label for="message">Message:</label><br>
        <textarea id="message" name="message" rows="4" cols="50"></textarea><br>
        <label for="phone">Phone Number:</label><br>
        <input type="text" id="phone" name="phone"><br>
        <input type="submit" value="Send SMS">
    </form>

    <?php
    // Function to send SMS using Telcomw API
    function sendSMS($messageBody, $phoneNumber, $apiKey, $password, $from) {
        // Construct the API URL
        $url = "https://telcomw.com/api-v2/text";

        // Initialize cURL session
        $ch = curl_init($url);

        // Construct the POST data
        $postData = array(
            'message' => $messageBody,
            'phone' => $phoneNumber,
            'api_key' => $apiKey,
            'password' => $password,
            'from' => $from
        );

        // Set cURL options
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($postData));
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);

        // Execute cURL session
        $response = curl_exec($ch);

        // Check for errors
        if (curl_errno($ch)) {
            echo 'Curl error: ' . curl_error($ch);
            return false;
        }

        // Close cURL session
        curl_close($ch);

        // Decode the response JSON
        $responseData = json_decode($response, true);

        // Check if the message was sent successfully
        if ($responseData && isset($responseData['status']) && $responseData['status'] == 'success') {
            return true;
        } else {
            return false;
        }
    }

    // Your Telcomw API credentials
    $apiKey = "g50Fa2AlRQziZf6m2dDy";
    $password = "yamikani2000";
    $from = "265998292856"; // Your registered Telcomw number

    if ($_SERVER["REQUEST_METHOD"] == "POST") {
        // Retrieve the message body and phone numbers from the form input
        $messageBody = $_POST['message'];
        $phoneNumber = $_POST['phone'];

        // Send the SMS using Telcomw API
        $smsSent = sendSMS($messageBody, $phoneNumber, $apiKey, $password, $from);

        // Check if the message was sent successfully
        if ($smsSent) {
            echo "Message sent successfully";
        } else {
            echo "Failed to send message";
        }
    }
    ?>
</body>
</html>
