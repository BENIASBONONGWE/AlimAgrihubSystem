<?php
// Function to send SMS using Telcomw API
function sendSMS($messageBody, $phoneNumber, $apiKey, $password, $from) {
    // Construct the API URL
    $url = "https://telcomw.com/api-v2/text";
    
    // Construct the POST data
    $postData = array(
        'message' => $messageBody,
        'phone' => $phoneNumber,
        'api_key' => $apiKey,
        'password' => $password,
        'from' => $from
    );

    // Initialize cURL session
    $ch = curl_init($url);

    // Set cURL options
    curl_setopt($ch, CURLOPT_POST, true);
    curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($postData));
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);

    // Execute cURL session
    $response = curl_exec($ch);

    // Close cURL session
    curl_close($ch);

    // Decode the response JSON
    $responseData = json_decode($response, true);

    // Check if the message was sent successfully
    if ($responseData && isset($responseData['status']) && $responseData['status'] == 'success') {
        return true;
    } else {
        return false;
    }
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Retrieve the message body and phone numbers from the form input
    $messageBody = $_POST['message'];
    $phoneNumber = isset($_POST['phone_input']) ? $_POST['phone_input'] : $_POST['phone']; // This will be pre-filled with the selected phone number or user input
    
    // Your Telcomw API credentials
    $apiKey = "g50Fa2AlRQziZf6m2dDy";
    $password = "yamikani2000";
    $from = "265998292856"; // Your registered Telcomw number
    
    // Send the SMS using Telcomw API
    $smsSent = sendSMS($messageBody, $phoneNumber, $apiKey, $password, $from);

    // Check if the message was sent successfully
    if ($smsSent) {
        // JavaScript for success pop-up
        echo '<script>alert("Message sent successfully");</script>';
        // Redirect to sendsms.php
        echo '<script>window.location.href = "sendsms.php";</script>';
        exit(); // Ensure that no other content is sent after the header
    } else {
        // JavaScript for error pop-up
        echo '<script>alert("Failed to send message");</script>';
    }
}
?>
